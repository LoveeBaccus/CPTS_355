from psbuiltins import Stacks
from elements import StrConstant, DictConstant
import unittest

class HW4Part1Tests(unittest.TestCase):
    def setUp(self):
        #create the Stack object
        self.psstacks = Stacks()
        #clear the opstack and the dictstack
        self.psstacks.clearBoth() 
    
    #Arithmatic operator tests
    def test_add(self):
        #9 3 add
        self.psstacks.opPush(9)
        self.psstacks.opPush(3)
        self.psstacks.add()
        self.assertEqual(self.psstacks.opPop(),12)

    def test_sub(self):
        #10 2 sub
        self.psstacks.opPush(10)
        self.psstacks.opPush(2)
        self.psstacks.sub()
        self.assertEqual(self.psstacks.opPop(),8)

    def test_mul(self):
        #2 40 mul
        self.psstacks.opPush(2)
        self.psstacks.opPush(40)
        self.psstacks.mul()
        self.assertEqual(self.psstacks.opPop(),80)

    def test_mod(self):
        #20 3 mod
        self.psstacks.opPush(20)
        self.psstacks.opPush(3)
        self.psstacks.mod()
        self.assertEqual(self.psstacks.opPop(),2)

    #-----------------------------------------------------
    #Comparison operators tests
    def test_eq1(self):
        #6 6 eq
        self.psstacks.opPush(6)
        self.psstacks.opPush(6)
        self.psstacks.eq()
        self.assertEqual(self.psstacks.opPop(),True)

    def test_eq2(self):
        # (WSU) (WSU) eq
        #compare values
        self.psstacks.opPush(StrConstant('(WSU)'))
        self.psstacks.opPush(StrConstant('(WSU)'))
        self.psstacks.eq()
        self.assertEqual(self.psstacks.opPop(),True)
        #compare objects
        s = StrConstant('(WSU)')
        self.psstacks.opPush(s)
        self.psstacks.opPush(s)
        self.psstacks.eq()
        self.assertEqual(self.psstacks.opPop(),True)

    def test_eq3(self):
        # 1 dict  2 dict 
        #compare objects
        d1 = DictConstant({})
        self.psstacks.opPush(d1)
        d2 = DictConstant({})
        self.psstacks.opPush(d2)
        self.psstacks.eq()
        self.assertEqual(self.psstacks.opPop(),False)
        self.psstacks.opPush(d1)
        #duplicate the object
        self.psstacks.dup()
        self.psstacks.eq()
        self.assertEqual(self.psstacks.opPop(),True)
    
    def test_lt(self):
        #3 6 lt
        self.psstacks.opPush(3)
        self.psstacks.opPush(6)
        self.psstacks.lt()
        self.assertEqual(self.psstacks.opPop(),True)

    def test_gt(self):
        #4 5 gt
        self.psstacks.opPush(4)
        self.psstacks.opPush(5)
        self.psstacks.gt()
        self.assertEqual(self.psstacks.opPop(),False)

    #-----------------------------------------------------
    

    # Tests for helper functions : define, lookup   
    def test_lookup1(self):
        self.psstacks.dictPush({'/v':3, '/x': 20})
        self.psstacks.dictPush({'/v':4, '/x': 10})
        self.psstacks.dictPush({'/v':5})
        self.assertEqual(self.psstacks.lookup('x'),10)
        self.assertEqual(self.psstacks.lookup('v'),5)
  
    def testLookup2(self):
        self.psstacks.dictPush({'/a':'(355)'})
        s = StrConstant('(355)')
        self.psstacks.dictPush({'/a':s})
        self.assertTrue(self.psstacks.lookup("a") is s)
        self.assertEqual(self.psstacks.lookup("a").value,s.value)

    def test_define1(self):
        self.psstacks.dictPush({})
        self.psstacks.define("/n1", 4)
        self.assertEqual(self.psstacks.lookup("n1"),4)

    def test_define2(self):
        self.psstacks.dictPush({})
        self.psstacks.define("/n1", 4)
        self.psstacks.define("/n1", 5)
        self.psstacks.define("/n2", 6)
        self.assertEqual(self.psstacks.lookup("n1"),5)
        self.assertEqual(self.psstacks.lookup("n2"),6)        

    def test_define3(self):
        self.psstacks.dictPush({})
        self.psstacks.define("/n1", 4)
        self.psstacks.dictPush({})
        self.psstacks.define("/n2", 6)
        self.psstacks.define("/n2", 7)
        self.psstacks.dictPush({})
        self.psstacks.define("/n1", 6)
        self.assertEqual(self.psstacks.lookup("n1"),6)
        self.assertEqual(self.psstacks.lookup("n2"),7)    
    
    #-----------------------------------------------------
    
    #String operator tests
    def test_string(self):
        # 3 string 
        self.psstacks.opPush(3)
        self.psstacks.string()
        d = self.psstacks.opPop() # pop the StrConstant value
        self.assertEqual(d.value,'(\x00\x00\x00)')  #the characters in the StrConstant's value should be initialized to '\0' , ascii NUL
        self.assertTrue(len(self.psstacks.opstack)==0)  

    def test_length_StrConstant(self):
        #(CptS355) length
        self.psstacks.opPush(StrConstant('(CptS355)'))
        self.psstacks.length()
        self.assertEqual(self.psstacks.opPop(),7)      
        self.assertTrue(len(self.psstacks.opstack)==0) 
        #length will not push back the StrConstant onto the opstack      

#    def test_get_StrConstant(self):


#    def test_put_StrConstant1(self):


#    def test_put_StrConstant2(self):
 
    def test_getinterval(self):
        #(WSU Pullman Campus) 4 7 getinterval
        self.psstacks.opPush(StrConstant('(WSU Pullman Campus)'))
        self.psstacks.opPush(4)
        self.psstacks.opPush(7)
        self.psstacks.getinterval()
        s =  self.psstacks.opPop() #pop the StrConstant slice
        self.assertEqual(s.value, '(Pullman)')
        self.assertTrue(len(self.psstacks.opstack)==0)
        #getinterval will not push back the original StrConstant onto the opstack 

#    def test_putinterval1(self):


#    def test_putinterval2(self):


#    def test_search1(self):

#    def test_search2(self):

    #-----------------------------------------------------
    #Dictionary operator tests

    def test_dict(self):
        # 10 dict 
        self.psstacks.opPush(10)
        self.psstacks.psDict()
        d = self.psstacks.opPop() # pop the DictConstant value
        self.assertEqual(d.value,{}) 
        self.assertTrue(len(self.psstacks.opstack)==0)  # dict should pop the size argument

#    def test_get_put_DictConstant1(self):


#    def test_get_put_DictConstant2(self):


#    def test_length_DictConstant(self):
 

    #-----------------------------------------------------
    #stack manipulation operator tests
    def test_dup(self):
        #(CptS355)  dup
        self.psstacks.opPush(StrConstant('(CptS355)'))
        self.psstacks.dup()
        isSame = self.psstacks.opPop() is self.psstacks.opPop()
        self.assertTrue(isSame)

    def test_exch(self):
        # /x 10 exch
        self.psstacks.opPush('/x')
        self.psstacks.opPush(10)
        self.psstacks.exch()
        self.assertEqual(self.psstacks.opPop(),'/x')
        self.assertEqual(self.psstacks.opPop(),10)

    def test_pop(self):
        l1 = len(self.psstacks.opstack)
        self.psstacks.opPush(10)
        self.psstacks.pop()
        l2 = len(self.psstacks.opstack)
        self.assertEqual(l1,l2)

    def test_copy(self):
        #true 1 3 4 3 copy
        self.psstacks.opPush(True)
        self.psstacks.opPush(1)
        self.psstacks.opPush(3)
        self.psstacks.opPush(4)
        self.psstacks.opPush(3)
        self.psstacks.copy()
        self.assertTrue(self.psstacks.opPop()==4 and self.psstacks.opPop()==3 and self.psstacks.opPop()==1 and self.psstacks.opPop()==4 and self.psstacks.opPop()==3 and self.psstacks.opPop()==1 and self.psstacks.opPop()==True)
        
    def test_clear(self):
        #10 /x clear
        self.psstacks.opPush(10)
        self.psstacks.opPush("/x")
        self.psstacks.clear()
        self.assertEqual(len(self.psstacks.opstack),0)

    #-----------------------------------------------------
    #dictionary stack operators

    def test_psDef(self):
        #/x 10 def /x 20 def x
        self.psstacks.dictPush({})
        self.psstacks.opPush("/x")
        self.psstacks.opPush(10)
        self.psstacks.psDef()
        self.psstacks.opPush("/x")
        self.psstacks.opPush(20)
        self.psstacks.psDef()
        self.assertEqual(self.psstacks.lookup('x'),20)

    def test_psDef2(self):
        #/x 10 def 1 dict begin /y 20 def x
        self.psstacks.dictPush({})
        self.psstacks.opPush("/x")
        self.psstacks.opPush(10)
        self.psstacks.psDef()
        self.psstacks.dictPush({})
        self.psstacks.opPush("/y")
        self.psstacks.opPush(20)
        self.psstacks.psDef()
        self.assertEqual(self.psstacks.lookup('x'),10)

#    def test_begin_end(self):


#    def test_dict_put_begin_end(self):
 

    def test_psDef3(self):
        #/x 3 def 1 dict begin /x 30 def 1 dict begin /x 300 def end x
        # define x in the bottom dictionary
        self.psstacks.dictPush({})
        self.psstacks.opPush("/x")
        self.psstacks.opPush(3)
        self.psstacks.psDef()
        # define x in the second dictionary
        self.psstacks.dictPush({})
        self.psstacks.opPush("/x")
        self.psstacks.opPush(30)
        self.psstacks.psDef()
        # define x in the third dictionary
        self.psstacks.dictPush({})
        self.psstacks.opPush("/x")
        self.psstacks.opPush(300)
        self.psstacks.psDef()
        self.psstacks.dictPop()
        self.assertEqual(self.psstacks.lookup('x'),30)

#-----------------------------------------------------



#-----------------------------------------------------

if __name__ == '__main__':
    unittest.main()

